$(document).ready(function(){
    $('#tablaKeys').bootstrapTable();
    $('#key_correo').addClass('form-control');
})
;
